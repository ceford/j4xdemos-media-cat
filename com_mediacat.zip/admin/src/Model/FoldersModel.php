<?php
/**
 * @package     Joomla.Administrator
 * @subpackage  com_mediacat
 *
 * @copyright   (C) 2017 Open Source Matters, Inc. <https://www.joomla.org>
 * @license     GNU General Public License version 2 or later; see LICENSE.txt
 */

namespace J4xdemos\Component\Mediacat\Administrator\Model;

\defined('_JEXEC') or die;

use Joomla\CMS\Factory;
use Joomla\CMS\Component\ComponentHelper;
use Joomla\CMS\MVC\Model\ListModel;
use Joomla\CMS\Plugin\PluginHelper;
use J4xdemos\Component\Mediacat\Administrator\Helper\MimetypesHelper;

use \RecursiveIteratorIterator;
use \RecursiveDirectoryIterator;

/**
 * Media View Model
 *
 * @since  4.0.0
 */
class FoldersModel extends ListModel
{
	/*
	 * Create hashes for all files in one folder using the catalogue
	 *
	 * $folder string relative to site root
	 * $media_type string either 'images' or 'files'
	 *
	 * return a list of catalogued files
	 */
	public function getHashes($media_type, $folder)
	{
		if (empty($folder))
		{
			return array ('That', 'went', 'wrong');
		}

		$params = ComponentHelper::getParams('com_mediacat');
		$table = '#__mediacat_' . $params->get($media_type . '_path');

		$db = Factory::getDbo();
		$query = $db->getQuery(true);
		// does the record exist
		$query->select('*');
		$query->from($table);

		$query->where('folder_path = ' . $db->quote($folder));
		$db->setQuery($query);
		$items = $db->loadObjectList();

		$new = 0;
		$old = 0;
		$dud = 0;

		foreach ($items as $item)
		{
			$file = JPATH_SITE . $item->folder_path . '/' . $item->file_name;

			if (file_exists($file))
			{
				$hash = hash('md5', $file);
			}
			else
			{
				$hash = '';
			}
			if (!empty($hash))
			{
				// has the hash changed
				if ($hash == $item->hash)
				{
					$old++;
				}
				else
				{
					$query = $db->getQuery(true);
					$query->update($table);
					$query->set('hash = ' . $db->quote($hash));
					$query->where('id = ' . $item->id);
					$db->setquery($query);
					$result = $db->execute();
					if (!empty($result))
					{
						$new++;
					}
				}
			}
			else
			{
				$dud++;
			}
		}
		return array('Folder = ' . $folder, ' New = ' . $new, ' Old = ' . $old . ', Missing = ' . $dud);
	}


	/*
	 * Get a list of all files in one folder and catalogue them
	 *
	 * $folder string relative to site root
	 * $media_type string either 'images' or 'files'
	 *
	 * return a list of catalogued files
	 */
	public function getFiles($media_type, $folder)
	{
		if (empty($folder))
		{
			return array ('That', 'went', 'wrong');
		}
		$path = JPATH_SITE . $folder;

		$folders[] = '/' . $folder;
		$params = ComponentHelper::getParams('com_mediacat');
		$mh = new MimetypesHelper;

		$items = scandir($path);

		$new = 0;
		$old = 0;
		$dud = 0;

		foreach ($items as $item)
		{
			// skip directories
			if (is_dir($item))
			{
				continue;
			}
			// skip hidden files
			if (strpos($item, '.') == 0)
			{
				continue;
			}
			// get mime type
			$mime = $mh->getFileMimeType($path . '/' . $item);
			// is it an allowed type
			if (empty($mh->checkInAllowedExtensions($mime, $params, $media_type)))
			{
				continue;
			}
			// save data as image or file
			if ($media_type == 'image')
			{
				$result = $this->saveImageData($folder, $item);
			} else {
				$result = $this->saveFileData($folder, $item);
			}
			if ($result == 'new')
			{
				$new++;
			}
			else if ($result == 'old')
			{
				$old++;
			}
			else
			{
				$dud++;
			}
		}

		return array('Folder = ' . $folder, ' New = ' . $new, ' Old = ' . $old, ' Dud = ' . $dud);
	}

	protected function saveImageData($folder, $filename)
	{
		$root = JPATH_SITE;

		$mh = new MimetypesHelper;
		$mime = $mh->getFileMimeType($root . $folder . '/' . $filename);
		// is it an svg
		if ($mime != 'image/svg+xml')
		{
			list($width, $height, $type, $wandhstring) = getimagesize($root. $folder. '/' . $filename);
		}
		else
		{
			$width = 100;
			$height = 100;
		}

		$size = filesize($root . $folder . '/' . $filename);

		// get the file name and extension
		$extension = substr($filename, strrpos($filename, '.') + 1);

		// takes 5x longer to hash - needs time saving ploy if file has not changed
		//$hash = hash('md5', $file);

		$db = Factory::getDbo();
		$query = $db->getQuery(true);
		// does the record exist
		$query->select('id');
		$query->from('#__mediacat_images');
		$query->where('folder_path = ' . $db->quote($folder));
		$query->where('file_name = ' . $db->quote($filename));
		$db->setQuery($query);
		$id = $db->loadResult();
		$query = $db->getQuery(true);
		if ($id)
		{
			$query->update('#__mediacat_images');
			$query->where('id = ' . $id);
			$result = 'old';
		}
		else
		{
			$query->insert('#__mediacat_images');
			$result = 'new';
		}
		$query->set('folder_path = ' . $db->quote($folder));
		$query->set('file_name = ' . $db->quote($filename));
		$query->set('extension = ' . $db->quote($extension));
		$query->set('width = ' . $db->quote($width));
		$query->set('height = ' . $db->quote($height));
		$query->set('size = ' . $db->quote($size));
		//$query->set('hash = ' . $db->quote($hash));

		$db->setQuery($query);
		try
		{
			$db->execute();
		}
		catch (\RuntimeException $e)
		{
			// skip this one
			return 'dud';
		}
		return $result;
	}

	protected function saveFileData($folder, $filename)
	{
		$root = JPATH_SITE;
		$size = filesize($root . $folder . '/' . $filename);

		// get the file name and extension
		$extension = substr($filename, strrpos($filename, '.') + 1);

		// takes 5x longer to hash - needs time saving ploy if file has not changed
		//$hash = hash('md5', $file);

		$db = Factory::getDbo();
		$query = $db->getQuery(true);
		// does the record exist
		$query->select('id');
		$query->from('#__mediacat_files');
		$query->where('folder_path = ' . $db->quote($folder));
		$query->where('file_name = ' . $db->quote($filename));
		$db->setQuery($query);
		$id = $db->loadResult();

		// if yes then update it
		$query = $db->getQuery(true);
		if ($id)
		{
			$query->update('#__mediacat_files');
			$query->where('id = ' . $id);
			$result = 'old';
		}
		else
		{
			$query->insert('#__mediacat_files');
			$result = 'new';
		}
		$query->set('folder_path = ' . $db->quote($folder));
		$query->set('file_name = ' . $db->quote($filename));
		$query->set('extension = ' . $db->quote($extension));
		$query->set('size = ' . $db->quote($size));
		//$query->set('hash = ' . $db->quote($hash));

		$db->setQuery($query);
		try
		{
			$db->execute();
		}
		catch (\RuntimeException $e)
		{
			// skip this one
			return 'dud';
		}
		return $result;
	}

	public function getFolders($folder)
	{
		// if folder is empty - abort
		if (empty($folder))
		{
			return array ('That', 'went', 'wrong');
		}
		$path = JPATH_SITE . '/' . $folder;
		$root = JPATH_SITE;
		$rootlen = strlen($root);
		$folders[] = '/' . $folder;

		try
		{
			$objects = new RecursiveIteratorIterator(new RecursiveDirectoryIterator($path),
				RecursiveIteratorIterator::SELF_FIRST);
			foreach($objects as $name => $object)
			{
				if (!is_dir($name))
				{
					continue;
				}
				$fileName = $object->getFilename();
				if ($fileName == '.' || $fileName == '..')
				{
					continue;
				}
				$folders[] = substr($name, $rootlen);
			}
			sort($folders);
		}
		catch (\Exception $e)
		{
			Factory::getApplication()->enqueueMessage('Bad path = ' . $path, 'warning');
		}
		return $folders;
	}
}
